const Attendance = require('../models/Attendance');

exports.getAllAttendance = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const { student_id, class_id, date } = req.query;

    const { data, total } = await Attendance.findAll({ limit, offset, student_id, class_id, date });

    res.json({
      success: true,
      count: data.length,
      total,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit)
      },
      data
    });
  } catch (error) {
    next(error);
  }
};

exports.getAttendanceById = async (req, res, next) => {
  try {
    const attendance = await Attendance.findById(req.params.id);
    if (!attendance) {
      const error = new Error('Attendance record not found');
      error.statusCode = 404;
      throw error;
    }
    res.json({ success: true, data: attendance });
  } catch (error) {
    next(error);
  }
};

exports.createAttendance = async (req, res, next) => {
  try {
    const attendanceId = await Attendance.create(req.body);
    res.status(201).json({
      success: true,
      message: 'Attendance record created successfully',
      data: { attendance_id: attendanceId, ...req.body }
    });
  } catch (error) {
    next(error);
  }
};

exports.updateAttendance = async (req, res, next) => {
  try {
    const attendance = await Attendance.findById(req.params.id);
    if (!attendance) {
      const error = new Error('Attendance record not found');
      error.statusCode = 404;
      throw error;
    }
    await Attendance.update(req.params.id, req.body);
    res.json({ success: true, message: 'Attendance record updated successfully' });
  } catch (error) {
    next(error);
  }
};

exports.deleteAttendance = async (req, res, next) => {
  try {
    const attendance = await Attendance.findById(req.params.id);
    if (!attendance) {
      const error = new Error('Attendance record not found');
      error.statusCode = 404;
      throw error;
    }
    await Attendance.delete(req.params.id);
    res.json({ success: true, message: 'Attendance record deleted successfully' });
  } catch (error) {
    next(error);
  }
};
