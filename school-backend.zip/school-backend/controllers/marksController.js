const Mark = require('../models/Mark');

exports.getAllMarks = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    const { student_id, exam_id } = req.query;

    const { data, total } = await Mark.findAll({ limit, offset, student_id, exam_id });

    res.json({
      success: true,
      count: data.length,
      total,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit)
      },
      data
    });
  } catch (error) {
    next(error);
  }
};

exports.getMarkById = async (req, res, next) => {
  try {
    const mark = await Mark.findById(req.params.id);
    if (!mark) {
      const error = new Error('Mark record not found');
      error.statusCode = 404;
      throw error;
    }
    res.json({ success: true, data: mark });
  } catch (error) {
    next(error);
  }
};

exports.createMark = async (req, res, next) => {
  try {
    const markId = await Mark.create(req.body);
    res.status(201).json({
      success: true,
      message: 'Mark record created successfully',
      data: { mark_id: markId, ...req.body }
    });
  } catch (error) {
    next(error);
  }
};

exports.updateMark = async (req, res, next) => {
  try {
    const mark = await Mark.findById(req.params.id);
    if (!mark) {
      const error = new Error('Mark record not found');
      error.statusCode = 404;
      throw error;
    }
    await Mark.update(req.params.id, req.body);
    res.json({ success: true, message: 'Mark record updated successfully' });
  } catch (error) {
    next(error);
  }
};

exports.deleteMark = async (req, res, next) => {
  try {
    const mark = await Mark.findById(req.params.id);
    if (!mark) {
      const error = new Error('Mark record not found');
      error.statusCode = 404;
      throw error;
    }
    await Mark.delete(req.params.id);
    res.json({ success: true, message: 'Mark record deleted successfully' });
  } catch (error) {
    next(error);
  }
};
