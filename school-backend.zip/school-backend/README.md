# Production-Ready School Management System API

A robust RESTful API built with Node.js, Express, and MySQL, following MVC architecture and industry best practices.

## Features

- **MVC Architecture**: Clean separation of concerns (Models, Views/Routes, Controllers).
- **Security**: 
  - `helmet` for security headers.
  - `cors` for Cross-Origin Resource Sharing.
  - Prepared statements to prevent SQL Injection.
- **Validation**: Robust request validation using `express-validator`.
- **Advanced API Features**:
  - **Pagination**: Support for `page` and `limit` query parameters.
  - **Filtering**: Filter results by date, student ID, exam ID, etc.
  - **Search**: Search exams by name.
- **Error Handling**: Centralized global error handling middleware.
- **Logging**: Request logging with `morgan`.
- **Database**: Connection pooling with `mysql2`.

## Prerequisites

- Node.js (v14+)
- MySQL Server

## Setup Instructions

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Environment Configuration**:
   - Copy `.env.example` to `.env`.
   - Update the database credentials in `.env`.

3. **Database Setup**:
   - Ensure the `school_management` database exists.
   - The API assumes the following tables are present: `exams`, `marks`, `attendance`, `students`, `subjects`, `classes`.

4. **Run the Server**:
   - Development mode: `node server.js` (or use `nodemon` if installed).

## API Documentation

### Base URL: `/api`

#### 1. Exams (`/api/exams`)
- `GET /?page=1&limit=10&search=Midterm&date=2023-10-01` - Get all exams (with pagination/filtering).
- `GET /:id` - Get single exam.
- `POST /` - Create exam (Requires: `exam_name`, `exam_date`).
- `PUT /:id` - Update exam.
- `DELETE /:id` - Delete exam.

#### 2. Marks (`/api/marks`)
- `GET /?page=1&limit=10&student_id=1&exam_id=2` - Get all marks (with JOINs and filtering).
- `GET /:id` - Get single mark record.
- `POST /` - Add marks (Requires: `student_id`, `subject_id`, `exam_id`, `marks_obtained`).
- `PUT /:id` - Update marks.
- `DELETE /:id` - Delete marks.

#### 3. Attendance (`/api/attendance`)
- `GET /?page=1&limit=10&student_id=1&date=2023-10-01` - Get all attendance (with filtering).
- `GET /:id` - Get single record.
- `POST /` - Mark attendance (Requires: `student_id`, `class_id`, `date`, `status`).
- `PUT /:id` - Update attendance.
- `DELETE /:id` - Delete attendance.

## Project Structure

```text
├── config/         # Database and app configuration
├── controllers/    # Request handling logic
├── middleware/     # Custom middleware (auth, error, validation)
├── models/         # Database interaction logic
├── routes/         # API route definitions
├── .env            # Environment variables
├── server.js       # Application entry point
└── package.json    # Dependencies and scripts
```
