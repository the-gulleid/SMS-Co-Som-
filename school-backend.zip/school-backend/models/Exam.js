const db = require('../config/db');

class Exam {
  static async findAll({ limit, offset, search, date }) {
    let query = 'SELECT * FROM exams WHERE 1=1';
    const params = [];

    if (search) {
      query += ' AND exam_name LIKE ?';
      params.push(`%${search}%`);
    }

    if (date) {
      query += ' AND exam_date = ?';
      params.push(date);
    }

    query += ' ORDER BY exam_date DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await db.query(query, params);
    const [[{ total }]] = await db.query('SELECT COUNT(*) as total FROM exams');
    
    return { data: rows, total };
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT * FROM exams WHERE exam_id = ?', [id]);
    return rows[0];
  }

  static async create(examData) {
    const { exam_name, exam_date } = examData;
    const [result] = await db.query(
      'INSERT INTO exams (exam_name, exam_date) VALUES (?, ?)',
      [exam_name, exam_date]
    );
    return result.insertId;
  }

  static async update(id, examData) {
    const { exam_name, exam_date } = examData;
    await db.query(
      'UPDATE exams SET exam_name = ?, exam_date = ? WHERE exam_id = ?',
      [exam_name, exam_date, id]
    );
  }

  static async delete(id) {
    await db.query('DELETE FROM exams WHERE exam_id = ?', [id]);
  }
}

module.exports = Exam;
