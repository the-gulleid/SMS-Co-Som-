const db = require('../config/db');

class Attendance {
  static async findAll({ limit, offset, student_id, class_id, date }) {
    let query = `
      SELECT a.*, s.full_name as student_name, c.class_name 
      FROM attendance a
      JOIN students s ON a.student_id = s.student_id
      JOIN classes c ON a.class_id = c.class_id
      WHERE 1=1
    `;
    const params = [];

    if (student_id) {
      query += ' AND a.student_id = ?';
      params.push(student_id);
    }

    if (class_id) {
      query += ' AND a.class_id = ?';
      params.push(class_id);
    }

    if (date) {
      query += ' AND a.date = ?';
      params.push(date);
    }

    query += ' LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await db.query(query, params);
    const [[{ total }]] = await db.query('SELECT COUNT(*) as total FROM attendance');
    
    return { data: rows, total };
  }

  static async findById(id) {
    const [rows] = await db.query(`
      SELECT a.*, s.full_name as student_name, c.class_name 
      FROM attendance a
      JOIN students s ON a.student_id = s.student_id
      JOIN classes c ON a.class_id = c.class_id
      WHERE a.attendance_id = ?
    `, [id]);
    return rows[0];
  }

  static async create(attendanceData) {
    const { student_id, class_id, date, status } = attendanceData;
    const [result] = await db.query(
      'INSERT INTO attendance (student_id, class_id, date, status) VALUES (?, ?, ?, ?)',
      [student_id, class_id, date, status]
    );
    return result.insertId;
  }

  static async update(id, attendanceData) {
    const { student_id, class_id, date, status } = attendanceData;
    await db.query(
      'UPDATE attendance SET student_id = ?, class_id = ?, date = ?, status = ? WHERE attendance_id = ?',
      [student_id, class_id, date, status, id]
    );
  }

  static async delete(id) {
    await db.query('DELETE FROM attendance WHERE attendance_id = ?', [id]);
  }
}

module.exports = Attendance;
