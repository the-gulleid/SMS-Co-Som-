const db = require('../config/db');

class Mark {
  static async findAll({ limit, offset, student_id, exam_id }) {
    let query = `
      SELECT m.*, s.full_name as student_name, sub.subject_name, e.exam_name 
      FROM marks m
      JOIN students s ON m.student_id = s.student_id
      JOIN subjects sub ON m.subject_id = sub.subject_id
      JOIN exams e ON m.exam_id = e.exam_id
      WHERE 1=1
    `;
    const params = [];

    if (student_id) {
      query += ' AND m.student_id = ?';
      params.push(student_id);
    }

    if (exam_id) {
      query += ' AND m.exam_id = ?';
      params.push(exam_id);
    }

    query += ' LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await db.query(query, params);
    const [[{ total }]] = await db.query('SELECT COUNT(*) as total FROM marks');
    
    return { data: rows, total };
  }

  static async findById(id) {
    const [rows] = await db.query(`
      SELECT m.*, s.full_name as student_name, sub.subject_name, e.exam_name 
      FROM marks m
      JOIN students s ON m.student_id = s.student_id
      JOIN subjects sub ON m.subject_id = sub.subject_id
      JOIN exams e ON m.exam_id = e.exam_id
      WHERE m.mark_id = ?
    `, [id]);
    return rows[0];
  }

  static async create(markData) {
    const { student_id, subject_id, exam_id, marks_obtained } = markData;
    const [result] = await db.query(
      'INSERT INTO marks (student_id, subject_id, exam_id, marks_obtained) VALUES (?, ?, ?, ?)',
      [student_id, subject_id, exam_id, marks_obtained]
    );
    return result.insertId;
  }

  static async update(id, markData) {
    const { student_id, subject_id, exam_id, marks_obtained } = markData;
    await db.query(
      'UPDATE marks SET student_id = ?, subject_id = ?, exam_id = ?, marks_obtained = ? WHERE mark_id = ?',
      [student_id, subject_id, exam_id, marks_obtained, id]
    );
  }

  static async delete(id) {
    await db.query('DELETE FROM marks WHERE mark_id = ?', [id]);
  }
}

module.exports = Mark;
