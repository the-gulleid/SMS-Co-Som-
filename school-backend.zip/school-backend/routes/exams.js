const express = require('express');
const router = express.Router();
const examsController = require('../controllers/examsController');
const { examValidation } = require('../middleware/validators');
const validate = require('../middleware/validate');

router.get('/', examsController.getAllExams);
router.get('/:id', examsController.getExamById);
router.post('/', examValidation, validate, examsController.createExam);
router.put('/:id', examValidation, validate, examsController.updateExam);
router.delete('/:id', examsController.deleteExam);

module.exports = router;
