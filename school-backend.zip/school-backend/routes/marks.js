const express = require('express');
const router = express.Router();
const marksController = require('../controllers/marksController');
const { markValidation } = require('../middleware/validators');
const validate = require('../middleware/validate');

router.get('/', marksController.getAllMarks);
router.get('/:id', marksController.getMarkById);
router.post('/', markValidation, validate, marksController.createMark);
router.put('/:id', markValidation, validate, marksController.updateMark);
router.delete('/:id', marksController.deleteMark);

module.exports = router;
