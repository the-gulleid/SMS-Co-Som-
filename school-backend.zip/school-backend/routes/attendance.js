const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const { attendanceValidation } = require('../middleware/validators');
const validate = require('../middleware/validate');

router.get('/', attendanceController.getAllAttendance);
router.get('/:id', attendanceController.getAttendanceById);
router.post('/', attendanceValidation, validate, attendanceController.createAttendance);
router.put('/:id', attendanceValidation, validate, attendanceController.updateAttendance);
router.delete('/:id', attendanceController.deleteAttendance);

module.exports = router;
