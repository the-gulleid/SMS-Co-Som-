const { body } = require('express-validator');

exports.examValidation = [
  body('exam_name').notEmpty().withMessage('Exam name is required').trim().isLength({ max: 100 }),
  body('exam_date').notEmpty().withMessage('Exam date is required').isDate().withMessage('Invalid date format')
];

exports.markValidation = [
  body('student_id').notEmpty().withMessage('Student ID is required').isInt(),
  body('subject_id').notEmpty().withMessage('Subject ID is required').isInt(),
  body('exam_id').notEmpty().withMessage('Exam ID is required').isInt(),
  body('marks_obtained').notEmpty().withMessage('Marks obtained is required').isInt({ min: 0 })
];

exports.attendanceValidation = [
  body('student_id').notEmpty().withMessage('Student ID is required').isInt(),
  body('class_id').notEmpty().withMessage('Class ID is required').isInt(),
  body('date').notEmpty().withMessage('Date is required').isDate().withMessage('Invalid date format'),
  body('status').notEmpty().withMessage('Status is required').isIn(['Present', 'Absent']).withMessage('Status must be Present or Absent')
];
